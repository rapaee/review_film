<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Film</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
</head>
<style>

</style>

<body class="bg-gray-100">
    
    <?php $__env->startSection('navbar-guest'); ?>
        <div class="container mx-auto p-4">
            <h2 class="text-xl font-bold mb-4 mt-40">Hasil Pencarian</h2>

            <?php if($film->isEmpty()): ?>
                <p class="text-gray-500">Tidak ada film yang ditemukan.</p>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    <?php $__currentLoopData = $film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('anonymous.detail-film', ['id' => $f->id_film])); ?>">
                            <div class="bg-white shadow-md rounded-lg overflow-hidden relative">
                                <div class="relative">
                                    <img src="<?php echo e(asset('storage/' . $f->poster)); ?>" alt="<?php echo e($f->judul); ?>"
                                        class="w-full h-56 object-cover">

                                    <!-- Rating di kanan atas -->
                                    <?php
                                        $rating = $f->averageRating ?? 0;
                                        $formattedRating =
                                            $rating == floor($rating)
                                                ? number_format($rating, 0)
                                                : number_format($rating, 1);
                                    ?>
                                    <div
                                        class="absolute top-2 right-2 bg-black bg-opacity-50 text-yellow-500 text-sm font-semibold px-2 py-1 rounded flex items-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24"
                                            class="w-4 h-4 mr-1">
                                            <path
                                                d="M12 .587l3.668 7.425 8.215 1.196-5.941 5.8 1.402 8.187L12 18.896l-7.344 3.86 1.402-8.187-5.941-5.8 8.215-1.196L12 .587z" />
                                        </svg>

                                        <p class="text-white text-sm ml-1"> <?php echo e($formattedRating); ?></p>
                                    </div>
                                </div>

                                <div class="p-4">
                                    <h3 class="text-lg font-semibold"><?php echo e($f->judul); ?></h3>
                                    <p class="text-gray-500">
                                        Tahun Rilis ( <?php echo e($f->tahun_rilis); ?> )<br>
                                        <span class="text-red-500">
                                            <?php if(isset($filmGenres[$f->id_film])): ?>
                                                <?php echo e($filmGenres[$f->id_film]->pluck('genre.title')->implode(', ')); ?>

                                            <?php else: ?>
                                                Tidak ada genre
                                            <?php endif; ?>
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('navbar-guest.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\review_film\resources\views/anonymous/search-film.blade.php ENDPATH**/ ?>