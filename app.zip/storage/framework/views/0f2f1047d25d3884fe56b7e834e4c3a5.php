<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film Populer</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    
    <?php $__env->startSection('navbar-guest'); ?>
    <div class="container mx-auto px-4 py-6">
        <h2 class="text-2xl font-bold mb-5 mt-32">Film Populer Paee Films</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('anonymous.detail-film', ['id' => $poster->film->id_film])); ?>" class="bg-white shadow-md rounded-lg overflow-hidden group">
                    <div class="relative">
                        <!-- Gambar Poster -->
                        <img src="<?php echo e(asset('storage/' . $poster->film->poster)); ?>" alt="<?php echo e($poster->film->judul); ?>" class="w-full h-56 object-cover group-hover:opacity-75 transition-all">
                        
                        <?php
                            // Cari film berdasarkan id_film dari poster
                            $film = $films->firstWhere('id_film', $poster->film->id_film);
                        ?>
                        
                        <?php
                        // Cari film berdasarkan id_film dari poster menggunakan dataFilm
                        $film = $dataFilm->firstWhere('id_film', $poster->film->id_film);
                    ?>
                    
                    <?php if($film): ?>
                        <div class="p-4">
                            <h3 class="text-lg font-semibold"><?php echo e($film->judul); ?></h3>
                            <p class="text-gray-500">Tahun Rilis (<?php echo e($film->tahun_rilis); ?>)</p>
                        </div>
                    <?php endif; ?>
                    
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php if(empty($comments)): ?>
            <p class="text-gray-500"></p>
        <?php endif; ?>
    </div>
    


   
    <?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('navbar-guest.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\review_film\resources\views/anonymous/filter-rating.blade.php ENDPATH**/ ?>