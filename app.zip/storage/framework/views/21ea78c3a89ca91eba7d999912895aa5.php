<?php echo e($slot); ?>

<?php /**PATH D:\laragon\www\review_film\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>