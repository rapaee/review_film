<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Detail Genre Relation</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    
    <?php $__env->startSection('navbar-admin'); ?>
    <form id="editGenreForm" action="${updateUrl}" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3 text-left">
            <label for="id_film" class="block text-sm font-medium text-gray-700">Judul Film:</label>
            <select id="id_filmz" name="id_film" tabindex="4" 
                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                <option value="">Pilih Film</option>
                <?php $__currentLoopData = $film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filmItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($filmItem->id_film); ?>" 
                        ${id_film == "<?php echo e($filmItem->id_film); ?>" ? 'selected' : ''}>
                        <?php echo e($filmItem->judul); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_film'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-700"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3 text-left">
            <label for="id_genre" class="block text-sm font-medium text-gray-700">Genre:</label>
            <div class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 sm:text-sm">
                <?php $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genreItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center mb-2">
                        <input type="checkbox" id="genre_<?php echo e($genreItem->id_genre); ?>" name="id_genre[]" value="<?php echo e($genreItem->id_genre); ?>" 
                            class="mr-2 border-gray-300 rounded focus:ring-indigo-500"
                            ${selectedGenres.includes("<?php echo e($genreItem->id_genre); ?>") ? 'checked' : ''}>
                        <label for="genre_<?php echo e($genreItem->id_genre); ?>" class="text-gray-700"><?php echo e($genreItem->title); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php $__errorArgs = ['id_genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-700"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </form>
    <?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('navbar-admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\review_film\resources\views/admin/detail-genre-relation.blade.php ENDPATH**/ ?>