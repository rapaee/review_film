<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Castings Film Detail</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="">
    

    <?php $__env->startSection('navbar-admin'); ?>
  
    <div class="">
    <h1 class="flex justify-center font-bold mb-4 mt-2 text-2xl">FORM EDIT CASTINGS</h1>
    <form action="   <?php echo e(route('admin.edit-castings-film-detail.update', $casting->id_castings)); ?> " method="POST" class="w-full bg-white p-6 rounded-lg shadow-md">
               
  
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-4 hidden">
            <label for="id_film" class="block text-sm font-medium text-gray-700 text-left">ID Film</label>
            <input type="text" id="id_film" name="id_film" class="mt-1 p-2 w-full border border-gray-300 rounded-md" value="<?php echo e(old('id_film',$casting->film->id_film)); ?>" readonly>
        </div>

        <div class="mb-4">
            <label for="nama_panggung" class="block text-sm font-medium text-gray-700 text-left">Nama Panggung</label>
            <input type="text" id="nama_panggung" name="nama_panggung" class="mt-1 p-2 w-full border border-gray-300 rounded-md" value="<?php echo e(old('nama_panggung', $casting->nama_panggung)); ?>" required>
        </div>

        <div class="mb-4">
            <label for="nama_asli" class="block text-sm font-medium text-gray-700 text-left">Nama Asli</label>
            <input type="text" id="nama_asli" name="nama_asli" class="mt-1 p-2 w-full border border-gray-300 rounded-md" value="<?php echo e(old('nama_asli', $casting->nama_asli)); ?>" required>
        </div>

        
        <div class="gap-3 flex justify-end">
           <a href="<?php echo e(route('admin.film-detail', ['id' => $casting->film->id_film])); ?>">
            <button class="w-20 bg-red-600 text-white p-1 h-8 rounded-md hover:bg-red-700 transition duration-200">
                Batal
            </button>
           </a>
            <button type="submit" class="w-20 bg-green-600 text-white p-1 h-8 rounded-md hover:bg-green-700 transition duration-200">
                Submit
            </button>
        </div>
    </form>
   </div>
    
    
    <?php $__env->stopSection(); ?>
    
</body>
</html>
<?php echo $__env->make('navbar-admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\review_film\resources\views/admin/edit-castings-film-detail.blade.php ENDPATH**/ ?>