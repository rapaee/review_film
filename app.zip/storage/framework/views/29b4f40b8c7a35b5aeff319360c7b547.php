<style>
    #dropdown-user {
  position: absolute;
  top: 100%;
  right: 0;
  min-width: 200px;
  z-index: 50;
}

</style>
<nav class="bg-white border-gray-200 dark:bg-[#17153B] w-full fixed z-50">
    <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
        <!-- Logo and Text -->
        <a href="<?php echo e(route('subcriber.home')); ?>" class="flex items-center space-x-3 rtl:space-x-reverse">
            <img src="https://cdn-icons-png.flaticon.com/128/1146/1146203.png" 
                 alt="" 
                 class="ml-2 w-8 h-8 filter invert md:block"> <!-- Hidden on small screens -->
            <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white hidden md:block">
                Paee Films
            </span> <!-- Hidden on small screens -->
        </a>
        
        <div class="flex md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse gap-4">
            <!-- Search Form -->
            <form class="max-w-md mx-auto">
                <label for="default-search" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">
                    Search
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 start-0 flex items-center ps-2 pointer-events-none">
                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                        </svg>
                    </div>
                    <input type="search" id="default-search" 
                           class="block w-full p-3 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" 
                           placeholder="Cari judul film ..." 
                           required>
                </div>
            </form>
  
            <div class="flex items-center ms-3">
                <div>
                  <button type="button" class="flex text-sm bg-gray-800 rounded-full focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600" aria-expanded="false" data-dropdown-toggle="dropdown-user">
                    <span class="sr-only">Open user menu</span>
                    <img class="w-8 h-8 rounded-full" src="https://flowbite.com/docs/images/people/profile-picture-5.jpg" alt="user photo">
                  </button>
                </div>
                <div class="z-50 hidden my-4 text-base list-none bg-white divide-y divide-gray-100 rounded shadow dark:bg-gray-700 dark:divide-gray-600" id="dropdown-user">
                  <div class="px-4 py-3" role="none">
                    <p class="text-sm text-gray-900 dark:text-white" role="none">
                      <?php echo e(Auth::user()->name); ?>

                    </p>
                    <p class="text-sm font-medium text-gray-900 truncate dark:text-gray-300" role="none">
                      <?php echo e(Auth::user()->email); ?>

                    </p>
                  </div>
                  <ul class="py-1" role="none">
                    <li>
                      <form method="POST" action="<?php echo e(route('logout')); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-600 dark:hover:text-white" onclick="this.closest('form').submit();">
                        <?php echo csrf_field(); ?>
                        
                        <span>Log out</span>
                    </form>
                    </li>
                  </ul>
                </div>
              </div>
        </div>
        
    </div>

    <div id="navbar" class="bg-[#1d1353] flex flex-wrap justify-center md:justify-normal">
      <!-- Dropdown 1 -->
      <div class="relative ml-0 md:ml-32">
          <button id="dropdownDelayButton" class="text-white0 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 inline-flex items-center dark:hover:bg-[#413778] text-white gap-2">
              <img src="https://cdn-icons-png.flaticon.com/128/974/974476.png" alt="" class="w-5 h-5 filter invert">
              <span>Genre</span>
              <img src="https://cdn-icons-png.flaticon.com/128/2722/2722987.png" alt="" class="w-3 h-3 filter invert">
          </button>
  
          <!-- Dropdown menu -->
          <div id="dropdownDelay" class="absolute w-64 bg-white divide-y divide-gray-100 rounded-lg shadow-lg hidden z-40 dark:bg-[#413778]">
              <ul class="grid grid-cols-2 gap-2 p-2 text-sm text-gray-700 dark:text-gray-200">
                  <?php $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                      <a href="<?php echo e(route('subcriber.film-genre', ['id' => $g->id_genre])); ?>" 
                         class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-[#2E236C]">
                         <?php echo e($g->title); ?>

                      </a>
                  </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
      </div>
  
      <!-- Dropdown 2 -->
      <div class="relative">
          <button id="dropdownDelayButton2" class="text-white0 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 inline-flex items-center dark:hover:bg-[#413778] text-white gap-2">
              <img src="https://cdn-icons-png.flaticon.com/128/535/535234.png" alt="" class="w-5 h-5 filter invert">
              <span>Paee</span>
              <img src="https://cdn-icons-png.flaticon.com/128/2722/2722987.png" alt="" class="w-3 h-3 filter invert">
          </button>
  
          <!-- Dropdown menu -->
          <div id="dropdownDelay2" class="absolute md:-ml-0 w-48 bg-white divide-y divide-gray-100 rounded-lg shadow-lg hidden z-40 dark:bg-[#413778]">
              <ul class="flex gap-2 p-2 text-sm text-gray-700 dark:text-gray-200">
                  <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-[#2E236C]">Terbaru</a></li>
                  <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-[#2E236C]">Popular</a></li>
              </ul>
          </div>
      </div>
  
      <!-- Dropdown 3 -->
      <div class="relative">
          <button id="dropdownDelayButton3" class="text-white0 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 inline-flex items-center dark:hover:bg-[#413778] text-white gap-2">
              <img src="https://cdn-icons-png.flaticon.com/128/2370/2370264.png" alt="" class="w-5 h-5 filter invert">
              <span>Tahun</span>
              <img src="https://cdn-icons-png.flaticon.com/128/2722/2722987.png" alt="" class="w-3 h-3 filter invert">
          </button>
  
          <!-- Dropdown menu -->
          <div id="dropdownDelay3" class="absolute -ml-[75px] md:-ml-0 w-48 bg-white divide-y divide-gray-100 rounded-lg shadow-lg hidden z-40 dark:bg-[#413778]">
              <ul class="flex gap-2 p-2 text-sm text-gray-700 dark:text-gray-200">
                  <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-[#2E236C]">Terbaru</a></li>
                  <li><a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-[#2E236C]">Popular</a></li>
              </ul>
          </div>
      </div>
  </div>
  
  </nav>



  <script>
    document.addEventListener('DOMContentLoaded', () => {
        // Fungsi untuk menangani dropdown
        const handleDropdown = (dropdownButtonId, dropdownMenuId) => {
            const dropdownButton = document.getElementById(dropdownButtonId);
            const dropdownMenu = document.getElementById(dropdownMenuId);
    
            dropdownButton.addEventListener('mouseenter', () => {
                dropdownMenu.classList.remove('hidden');
            });
    
            dropdownButton.addEventListener('mouseleave', () => {
                setTimeout(() => {
                    if (!dropdownMenu.matches(':hover')) {
                        dropdownMenu.classList.add('hidden');
                    }
                }, 0.5); // Ganti angka ini untuk mengatur delay
            });
    
            dropdownMenu.addEventListener('mouseleave', () => {
                dropdownMenu.classList.add('hidden');
            });
    
            dropdownMenu.addEventListener('mouseenter', () => {
                dropdownMenu.classList.remove('hidden');
            });
        };
    
        // Panggil fungsi handleDropdown untuk masing-masing ID dropdown
        handleDropdown('dropdownDelayButton', 'dropdownDelay');
        handleDropdown('dropdownDelayButton2', 'dropdownDelay2');
        handleDropdown('dropdownDelayButton3', 'dropdownDelay3');
    });
    
    </script>
    
    <script>
      document.addEventListener('DOMContentLoaded', () => {
      const toggleButton = document.querySelector('[data-collapse-toggle="navbar-cta"]');
      const navbar = document.getElementById('navbar-cta');
  
      if (toggleButton && navbar) {
          toggleButton.addEventListener('click', () => {
              navbar.classList.toggle('hidden');
          });
      }
  });
  
  //open profile
  document.addEventListener('DOMContentLoaded', function() {
  const button = document.querySelector('[data-dropdown-toggle="dropdown-user"]');
  const dropdown = document.getElementById('dropdown-user');

  button.addEventListener('click', function() {
    dropdown.classList.toggle('hidden');
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', function(event) {
    if (!button.contains(event.target) && !dropdown.contains(event.target)) {
      dropdown.classList.add('hidden');
    }
  });
});
    </script>
     <div class="">
      <?php echo $__env->yieldContent('navbar-subcriber'); ?>
  </div>
  <?php /**PATH D:\laragon\www\review_film\resources\views/navbar-subcriber/navbar.blade.php ENDPATH**/ ?>