<script src="https://cdn.tailwindcss.com"></script>

<body class="bg-gray-100">
    
    <?php $__env->startSection('navbar-guest'); ?>
        <div class="py-12 mt-28">
            
            
            <div class="max-w-4xl object-cover sm:max-w-5xl md:max-w-md lg:max-w-7xl mx-auto space-y-6">
                <!-- Form Update Profile Information -->
                <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

                <!-- Form Update Password -->
                <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

                <!-- Form Delete User -->
                <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
</body>

<?php echo $__env->make('navbar-guest.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\review_film\resources\views/profile/edit.blade.php ENDPATH**/ ?>